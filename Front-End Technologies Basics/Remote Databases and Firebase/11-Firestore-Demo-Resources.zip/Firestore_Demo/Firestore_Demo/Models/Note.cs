﻿namespace Firestore_Demo.Models
{
    public class Note
    {
    }
}
