using LibraryManagementSystem;

namespace LibraryManagementTest
{
        [TestFixture]
        public class LibraryTests
        {
            

            [SetUp]
            public void SetUp()
            {
                
            }

            [Test]
            public void Test1()
            {
                
            }


            
            
        }
    }
